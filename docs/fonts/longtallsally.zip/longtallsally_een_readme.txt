########################################################################

>> ABOUT AESTHETIX FONT COMPANY

Aesthetix Font Company was founded in 1999 as a division of Aesthetix 
Graphic Design. We create original, free fonts for the world to use
however they see fit.

########################################################################

>> ABOUT LONG TALL SALLY EEN

Long Tall Sally EEN
Aesthetix Font Company, font #00003
created December 16-19, 2000

Long Tall Sally EEN was created in December, 2000 by Aesthetix Graphic
Design exclusively for Famous Fonts
(www.eliteentertainment.net/famousfonts). It is based on the typeface
used on several logos, including the Guns 'N Roses 'Use Your Illusion'
albums and the 'Final Fantasy' role palying games. As far as we could 
tell, a freeware version of this font was not available, so we made one.
This is NOT a pirated or renamed font. True, it may look just like 
another or several other fonts out there (and may even have the same 
character set), but it is an original.

The name Long Tall Sally EEN comes from the Little Richard classic
(later covered by the Beatles). The letters are long, tall, and skinny.

########################################################################

>> LONG TALL SALLY EEN USAGE

You are free to use Long Tall Sally EEN however you see fit. You can
even screw around with it, destroy it, and remix it to create a new
font.

However you use this font, please let us know - we like to see how
our fonts are used. You can write to use at
fonts@eliteentertainment.net or fill out our online feedback form at
http://www.eliteentertainment.net/feedback.html

This font would not exist without the help of CybaPee - visit CybaPee's
TypOasis at http://moorstation.org/typoasis/typoasis.htm

########################################################################

>> LONG TALL SALLY EEN DISTRIBUTION

We strongly encourage the distribution of this font on the web and in 
newsgroups, through email, etc. We only ask that you keep it with this
readme file.

This font may be freely distributed but may not be sold or included in
any software or archive which is being sold.


The Elite Entertainment Network
www.eliteentertainment.net